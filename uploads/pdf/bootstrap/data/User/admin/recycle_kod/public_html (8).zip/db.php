 
<?php
$host = "localhost";  
$username = "u681343650_devdutt";  
$password = "Devdutt@1234569";       
$database = "u681343650_devdutt"; 

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
