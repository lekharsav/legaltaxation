<?php
// Include database configuration
require_once 'db.php';

// Process form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate input data
    $name = htmlspecialchars(trim($_POST['name']));
    $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
    $phone = htmlspecialchars(trim($_POST['phone']));
    $service = htmlspecialchars(trim($_POST['service']));
    $message = htmlspecialchars(trim($_POST['message']));
    
    // Validate required fields
    if (empty($name) || empty($email) || empty($service)) {
        // Redirect back with error
        header("Location: index.html?form=error");
        exit;
    }
    
    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO contacts (name, email, phone, service, message) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $email, $phone, $service, $message);
    
    // Execute the statement
    if ($stmt->execute()) {
        // Success - redirect to thank you page or back with success message
        header("Location: index.php?form=success");
    } else {
        // Error - redirect back with error
        header("Location: index.php?form=error");
    }
    
    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    // Not a POST request, redirect to home
    header("Location: index.php");
}
exit;
?>