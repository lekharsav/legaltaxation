<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>DEBDARSHAN</title>
  <link rel="icon" href="images/logo.png" type="image/png" />
  <link rel="stylesheet" href="style.css" />
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
</head>

 <style>
    /* Additional styles for phone call buttons */
    .call-now-banner {
      background: linear-gradient(135deg, #6e48aa 0%, #9d50bb 100%);
      color: white;
      padding: 20px;
      text-align: center;
      margin: 30px 0;
      border-radius: 10px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
      position: relative;
      overflow: hidden;
    }
    
    .call-now-banner::before {
      content: "";
      position: absolute;
      top: -50%;
      left: -50%;
      width: 200%;
      height: 200%;
      background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 70%);
      transform: rotate(30deg);
      animation: shine 3s infinite;
    }
    
    @keyframes shine {
      0% { transform: rotate(30deg) translate(-30%, -30%); }
      100% { transform: rotate(30deg) translate(30%, 30%); }
    }
    
    .call-now-banner h3 {
      margin: 0 0 10px;
      font-size: 1.5rem;
    }
    
    .call-now-number {
      display: inline-block;
      background: white;
      color: #6e48aa;
      padding: 12px 25px;
      border-radius: 50px;
      font-weight: bold;
      font-size: 1.3rem;
      text-decoration: none;
      margin: 10px 0;
      transition: all 0.3s ease;
      box-shadow: 0 3px 10px rgba(0,0,0,0.2);
    }
    
    .call-now-number:hover {
      transform: translateY(-3px);
      box-shadow: 0 5px 15px rgba(0,0,0,0.3);
      background: #f8f9fa;
    }
    
    .call-now-number i {
      margin-right: 8px;
    }
    
    .call-now-text {
      font-size: 0.9rem;
      opacity: 0.9;
      margin-top: 10px;
    }
    
    @media (max-width: 768px) {
      .call-now-banner h3 {
        font-size: 1.2rem;
      }
      
      .call-now-number {
        font-size: 1.1rem;
        padding: 10px 20px;
      }
    }
      .fixed-call-button {
      position: fixed;
      bottom: 20px;
      right: 20px;
      background: #6e48aa;
      color: white;
      width: 60px;
      height: 60px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      text-decoration: none;
      transition: all 0.3s ease;
      z-index: 1000;
    }
    
    .fixed-call-button:hover {
      transform: scale(1.1);
      background: #9d50bb;
      box-shadow: 0 6px 15px rgba(0,0,0,0.4);
    }
    
    .fixed-call-button i {
      font-size: 1.8rem;
    }
    
    @media (max-width: 768px) {
      .call-now-banner h3 {
        font-size: 1.2rem;
      }
      
      .call-now-number {
        font-size: 1.1rem;
        padding: 10px 20px;
      }
      
      .fixed-call-button {
        width: 50px;
        height: 50px;
      }
      
      .fixed-call-button i {
        font-size: 1.5rem;
      }
    }
  </style>

<body>
  <!-- Header Section -->
  <header class="header">
    <div class="container">
      <div class="logo">
  <img src="images/logo.png" alt="Debdarshan Logo" style="height: 40px;" />
  <p>Unlock Your Destiny</p>
</div>
      <nav class="navbar">
        <ul>
          <li><a href="#home">Home</a></li>
          <li><a href="#about">About</a></li>
          <li><a href="#services">Services</a></li>
          <li><a href="#contact">Contact</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <!-- About Section -->
  <section class="about" id="about">
    <div class="container">
      <h2 class="section-title">Astronama Achariya Debdutta</h2>
      <div class="about-content">
        <div class="about-text">
          <h3>Astronama Achariya Debdutta</h3>
          <p>
            With over 25 years of experience in Vedic astrology, Astronama Achariya Debdutta has helped thousands of clients find clarity and
            direction in their lives. His accurate predictions and practical
            remedies have earned him recognition as one of the most trusted
            astrologers in the country.
          </p>
          <p>
            Specializing in birth chart analysis, planetary remedies, and life
            path guidance, Master Pandit combines ancient wisdom with modern
            interpretation to provide actionable insights.
          </p>
          <div class="about-buttons">
            <a href="#services" class="btn">Services</a>
            <a href="#contact" class="btn btn-outline">Contact Us</a>
          </div>
        </div>
        <div class="about-image">
          <img src="images/astro_bengali.jpeg" alt="Astrology Chart" />
        </div>
      </div>
    </div>
  </section>
  
  <div class="container">
    <div class="call-now-banner">
      <h3>Need Immediate Astrological Guidance?</h3>
      <a href="tel:+918240404258" class="call-now-number">
        <i class="fas fa-phone-alt"></i> 9330027339/9830078634
      </a>
      <p class="call-now-text">Call now for immediate consultation and remedies</p>
    </div>
  </div>


  <!-- Services Section -->
  <section class="services" id="services">
    <div class="container">
      <h2 class="section-title">Services</h2>
      <p class="section-subtitle">
        Personalized solutions for every aspect of your life
      </p>

      <div class="services-grid">
        <!-- Service 1 -->
        <div class="service-card">
          <div class="service-img">
            <img src="images/astrology-tips.jpg" alt="Astrology Tips" />
          </div>
          <div class="service-content">
            <h3>Astrology Tips</h3>
            <p>
              Daily, weekly and monthly astrological guidance to help you make
              the most of planetary influences.
            </p>
           
          </div>
        </div>

        <!-- Service 2 -->
        <div class="service-card">
          <div class="service-img">
            <img src="images/horoscope-service.jpg" alt="Horoscope Service" />
          </div>
          <div class="service-content">
            <h3>Horoscope Service</h3>
            <p>
              Detailed birth chart analysis with predictions for career,
              relationships, health and finances.
            </p>
          
          </div>
        </div>

        <!-- Service 3 -->
        <div class="service-card">
          <div class="service-img">
            <img src="images/zodiac.jpg" alt="Gemini Reading" />
          </div>
          <div class="service-content">
            <h3>Zodiac Sign Reading</h3>
            <p>
              In-depth analysis of your sun sign with predictions and
              compatibility reports.
            </p>
          
          </div>
        </div>

        <!-- Service 4 -->
        <div class="service-card">
          <div class="service-img">
            <img src="images/name.jpg" alt="Name Analysis" />
          </div>
          <div class="service-content">
            <h3>Name Analysis</h3>
            <p>
              Numerological evaluation of your name and suggestions for
              improvement if needed.
            </p>
           
          </div>
        </div>

        <!-- Service 5 -->
        <div class="service-card">
          <div class="service-img">
            <img src="images/Career.jpg" alt="Career Guidance" />
          </div>
          <div class="service-content">
            <h3>Career Guidance</h3>
            <p>
              Astrological assessment of your career path and timing for
              important decisions.
            </p>
  
          </div>
        </div>

        <!-- Service 6 -->
        <div class="service-card">
          <div class="service-img">
            <img src="images/gem.jpg" alt="Gem Stone" />
          </div>
          <div class="service-content">
            <h3>Gemstone Recommendation</h3>
            <p>
              Personalized gemstone suggestions based on your birth chart for
              planetary benefits.
            </p>
          
          </div>
        </div>

        <!-- Service 7 -->
        <div class="service-card">
          <div class="service-img">
            <img src="images/kundali.jfif" alt="Kundali Dosh" />
          </div>
          <div class="service-content">
            <h3>Kundali Dosh Analysis</h3>
            <p>
              Identification and remedies for various doshas in your birth
              chart.
            </p>
           
          </div>
        </div>

        <!-- Service 8 -->
        <div class="service-card">
          <div class="service-img">
            <img src="images/marriage.png" alt="Marriage Compatibility" />
          </div>
          <div class="service-content">
            <h3>Marriage Compatibility</h3>
            <p>
              Detailed analysis of compatibility between partners for
              harmonious marriage.
            </p>
          
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Testimonials Section -->
  <section class="testimonials">
    <div class="container">
      <h2 class="section-title" style="color: white">Client Testimonials</h2>
      <p class="section-subtitle" style="color: white">
        What our clients say about us
      </p>

      <div class="testimonial-slider">
        <!-- Testimonial 1 -->
        <div class="testimonial-slide active">
          <div class="testimonial-card">
            <div class="testimonial-content">
              <p>
                "Panditji-r poramorshe amar career-er shobcheye boro siddhanto
                niyechhi. Tar bhobishyobani obishshashyo rokom shothik
                chhilo."
              </p>
            </div>
            <div class="testimonial-author">
              <h4>Sumona Banerjee</h4>
              <p style="color: white">Kolkata</p>
            </div>
          </div>
        </div>

        <!-- Testimonial 2 -->
        <div class="testimonial-slide">
          <div class="testimonial-card">
            <div class="testimonial-content">
              <p>
                "Biye songkranto report-ti amake ekta bhul somparko theke
                bachiyechhe. Panditji-r poramorsher jonno ami chirorini."
              </p>
            </div>
            <div class="testimonial-author">
              <h4>Rajib Mukherjee</h4>
              <p style="color: white">Howrah</p>
            </div>
          </div>
        </div>

        <!-- Testimonial 3 -->
        <div class="testimonial-slide">
          <div class="testimonial-card">
            <div class="testimonial-content">
              <p>
                "Panditji-r ratno poramorsho amar jibon bodle diyechhe. Matro
                koyek masher modhye ami aschorjyo unnati dekhte peyechhi."
              </p>
            </div>
            <div class="testimonial-author">
              <h4>Arpita Ghosh</h4>
              <p style="color: white">Durgapur</p>
            </div>
          </div>
        </div>

        <!-- Testimonial 4 -->
        <div class="testimonial-slide">
          <div class="testimonial-card">
            <div class="testimonial-content">
              <p>
                "Jyotishshastrer madhyome Panditji amar shastho somoshyar
                shothik karon chinhoito korechhen ebong karyokori somadhan
                diyechhen."
              </p>
            </div>
            <div class="testimonial-author">
              <h4>Debjyoti Chakraborty</h4>
              <p style="color: white">Bardhaman</p>
            </div>
          </div>
        </div>

        <!-- Testimonial 5 -->
        <div class="testimonial-slide">
          <div class="testimonial-card">
            <div class="testimonial-content">
              <p>
                "Naam poribortoner poramorsho newar por theke amar jiboner
                shob badha dur hoye gechhe. Panditji shotyi aschorjyo!"
              </p>
            </div>
            <div class="testimonial-author">
              <h4>Tanima Das</h4>
              <p style="color: white">Siliguri</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Slider Controls -->
      <div class="slider-controls">
        <button class="slider-prev">
          <i class="fas fa-chevron-left"></i>
        </button>
        <div class="slider-dots"></div>
        <button class="slider-next">
          <i class="fas fa-chevron-right"></i>
        </button>
      </div>
    </div>
  </section>
  
  <div class="container">
    <div class="call-now-banner">
      <h3>Need Immediate Astrological Guidance?</h3>
      <a href="tel:+918240404258" class="call-now-number">
        <i class="fas fa-phone-alt"></i> 9330027339/9830078634
      </a>
      <p class="call-now-text">Call now for immediate consultation and remedies</p>
    </div>
  </div>

  <!-- Contact Section -->
  <section class="contact" id="contact">
    <div class="container">
      <h2 class="section-title">Contact Us</h2>
      <p class="section-subtitle">
        Get your personalized astrological consultation today
      </p>

      <div class="contact-content">
        <div class="contact-info">
          <h3>Contact Information</h3>
          <div class="info-item">
            <i class="fas fa-map-marker-alt"></i>
            <p>115D Rashbehari Avenue, Kolkata- 700029</p>
          </div>
          <div class="info-item">
            <i class="fas fa-phone"></i>
           <p><a href="tel:+919330027339">9330027339</a> / <a href="tel:+919830078634">9830078634</a></p>
          </div>
          <div class="info-item">
            <i class="fas fa-envelope"></i>
            <p>achariyadebdutta@gmail.com</p>
          </div>
          <div class="info-item">
            <i class="fas fa-clock"></i>
            <p>Monday to Saturday: 9:00 AM - 11:00 PM</p>
          </div>
        </div>

        <div class="contact-form">
          <!-- ✅ Success/Error message -->
          <?php if (isset($_GET['form']) && $_GET['form'] === 'success'): ?>
            <div style="background-color: #d4edda; color: #155724; padding: 12px; border-radius: 6px; margin-bottom: 20px; border: 1px solid #c3e6cb;">
              ✅ Thank you! Your message has been sent successfully.
            </div>
          <?php elseif (isset($_GET['form']) && $_GET['form'] === 'error'): ?>
            <div style="background-color: #f8d7da; color: #721c24; padding: 12px; border-radius: 6px; margin-bottom: 20px; border: 1px solid #f5c6cb;">
              ❌ Oops! Something went wrong. Please check your inputs and try again.
            </div>
          <?php endif; ?>
          <form action="process_form.php" method="POST">
            <div class="form-group">
              <input
                type="text"
                name="name"
                placeholder="Your Name"
                required />
            </div>
            <div class="form-group">
              <input
                type="email"
                name="email"
                placeholder="Your Email"
                required />
            </div>
            <div class="form-group">
              <input
                type="tel"
                name="phone"
                placeholder="Your Phone Number" />
            </div>
            <div class="form-group">
              <select name="service" required>
                <option value="" disabled selected>Select Service</option>
                <option value="Horoscope Reading">Horoscope Reading</option>
                <option value="Career Guidance">Career Guidance</option>
                <option value="Marriage Compatibility">
                  Marriage Compatibility
                </option>
                <option value="Gemstone Recommendation">
                  Gemstone Recommendation
                </option>
                <option value="Kundali Dosh Analysis">
                  Kundali Dosh Analysis
                </option>
                <option value="Name Analysis">Name Analysis</option>
                <option value="Health Tips">Health Tips</option>
                <option value="Pregnancy Guidance">Pregnancy Guidance</option>
                <option value="Numerology">Numerology</option>
              </select>
            </div>
            <div class="form-group">
              <textarea
                name="message"
                placeholder="Your Message or Specific Requirements"></textarea>
            </div>
            <div class="form-group">
              <button type="submit" class="btn">Send Message</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>
  
  
   <a href="tel:+919330027339" class="fixed-call-button">
    <i class="fas fa-phone-alt"></i>
  </a>

  <!-- Footer -->
  <footer class="footer">
    <div class="container">
      <div class="footer-content">
        <div class="footer-about">
          <h3>Debdarshan Wisdom</h3>
          <p>
            Providing accurate astrological guidance since 1995. Helping
            clients navigate life's challenges through the wisdom of the
            stars.
          </p>
          <div class="social-links">
            <a href="#"><i class="fab fa-facebook-f"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-youtube"></i></a>
          </div>
        </div>

        <div class="footer-links">
          <h3>Quick Links</h3>
          <ul>
            <li><a href="#home">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="#contact">Contact</a></li>
            <li><a href="privacy-policy.php">Privacy Policy</a></li>
          </ul>
        </div>

        <div class="footer-services">
          <h3>Our Services</h3>
          <ul>
            <li><a href="#">Horoscope Reading</a></li>
            <li><a href="#">Career Guidance</a></li>
            <li><a href="#">Marriage Compatibility</a></li>
            <li><a href="#">Gemstone Recommendation</a></li>
            <li><a href="#">Numerology</a></li>
          </ul>
        </div>

        <div class="footer-contact">
          <h3>Contact Us</h3>
          <p>
            <i class="fas fa-map-marker-alt"></i> 123 Kolkata
          </p>
          <p><i class="fas fa-phone"></i> 9330027339/9830078634</p>
          <p><i class="fas fa-envelope"></i> achariyadebdutta@gmail.com</p>
        </div>
      </div>

      <div class="footer-bottom">
        <p>&copy; 2025 AIM Digitalise. All Rights Reserved.</p>
      </div>
    </div>
  </footer>
  <script>
    document.addEventListener("DOMContentLoaded", function() {
      const slides = document.querySelectorAll(".testimonial-slide");
      const dotsContainer = document.querySelector(".slider-dots");
      const prevBtn = document.querySelector(".slider-prev");
      const nextBtn = document.querySelector(".slider-next");
      let currentSlide = 0;

      // Create dots
      slides.forEach((_, index) => {
        const dot = document.createElement("div");
        dot.classList.add("slider-dot");
        if (index === 0) dot.classList.add("active");
        dot.addEventListener("click", () => goToSlide(index));
        dotsContainer.appendChild(dot);
      });

      const dots = document.querySelectorAll(".slider-dot");

      // Show current slide
      function showSlide(index) {
        slides.forEach((slide) => slide.classList.remove("active"));
        dots.forEach((dot) => dot.classList.remove("active"));

        slides[index].classList.add("active");
        dots[index].classList.add("active");
        currentSlide = index;
      }

      // Next slide
      function nextSlide() {
        currentSlide = (currentSlide + 1) % slides.length;
        showSlide(currentSlide);
      }

      // Previous slide
      function prevSlide() {
        currentSlide = (currentSlide - 1 + slides.length) % slides.length;
        showSlide(currentSlide);
      }

      // Go to specific slide
      function goToSlide(index) {
        showSlide(index);
      }

      // Event listeners
      nextBtn.addEventListener("click", nextSlide);
      prevBtn.addEventListener("click", prevSlide);

      // Auto slide change every 5 seconds
      setInterval(nextSlide, 5000);
    });
  </script>
</body>

</html>