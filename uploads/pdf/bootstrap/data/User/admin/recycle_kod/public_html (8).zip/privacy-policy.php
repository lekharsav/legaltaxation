<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>DEBDARSHAN Privacy Policy</title>
  <link rel="icon" href="images/logo.png" type="image/png" />
  <link rel="stylesheet" href="style.css" />
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #fdfdfd;
    }

    .privacy-container {
      padding: 40px;
      max-width: 800px;
      margin: auto;
      line-height: 1.6;
    }

    h1, h2 {
      color: #4a148c;
    }

    section {
      margin-bottom: 40px;
    }
  </style>
</head>

<body>
  <!-- Header Section -->
  <header class="header">
    <div class="container">
      <div class="logo">
        <img src="images/logo.png" alt="Debdarshan Logo" style="height: 40px;" />
        <p>Unlock Your Destiny</p>
      </div>
      <nav class="navbar">
        <ul>
          <li><a href="#home">Home</a></li>
          <li><a href="#about">About</a></li>
          <li><a href="#services">Services</a></li>
          <li><a href="#contact">Contact</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <div class="privacy-container">
    <h1>Privacy Policy</h1>

    <section>
      <h2>1. Introduction</h2>
      <p>We value your privacy and are committed to protecting your personal information. This Privacy Policy explains how we collect, use, store, and safeguard your data when you visit our website or engage with our astrology consultation services, whether online or offline.</p>
    </section>

    <section>
      <h2>2. Information We Collect</h2>
      <p>We collect the following types of personal information:</p>
      <ul>
        <li>Contact Information: Name, email address, phone number, WhatsApp number.</li>
        <li>Birth Details: Date of birth, time of birth, place of birth (for horoscope analysis).</li>
        <li>Personal Information: Gender, marital status, profession, and other relevant details provided voluntarily during consultations.</li>
        <li>Technical Data: IP address, browser type, device information, and interaction data through cookies or analytics tools (if applicable).</li>
      </ul>
    </section>

    <section>
      <h2>3. How We Use Your Information</h2>
      <ul>
        <li>To provide personalized astrology reports and consultations.</li>
        <li>To communicate with you via phone, WhatsApp, or email.</li>
        <li>To improve our services and customer experience.</li>
        <li>To send appointment confirmations, service updates, or promotional messages (only with consent).</li>
        <li>To maintain records for legal, tax, and internal purposes.</li>
      </ul>
    </section>

    <section>
      <h2>4. How We Share Your Information</h2>
      <p>We do not sell, trade, or rent your personal information to any third party. Your data may be shared only in the following circumstances:</p>
      <ul>
        <li>With trusted team members involved in preparing your report or consultation (bound by confidentiality).</li>
        <li>If required by law, court order, or government authority.</li>
        <li>With service providers (e.g., secure payment gateways, communication tools) necessary to complete your transaction, under strict confidentiality.</li>
      </ul>
    </section>

    <section>
      <h2>5. Data Storage and Security</h2>
      <p>We store your data securely using encrypted systems and password-protected devices. All digital records are accessible only by authorized personnel. We regularly update our security protocols to protect your data from unauthorized access, misuse, or disclosure.</p>
    </section>

    <section>
      <h2>6. Cookies and Tracking</h2>
      <p>Our website may use cookies to enhance user experience and analyze web traffic. You can choose to disable cookies in your browser settings, although some features of the website may not function properly as a result.</p>
    </section>

    <section>
      <h2>7. User Rights</h2>
      <p>As a client, you have the right to:</p>
      <ul>
        <li>Access the personal data we hold about you.</li>
        <li>Request corrections to inaccurate or outdated information.</li>
        <li>Request deletion of your data (subject to legal and business obligations).</li>
        <li>Opt-out of promotional communications at any time.</li>
      </ul>
      <p>To exercise these rights, please contact us at [Your Email or WhatsApp].</p>
    </section>

    <section>
      <h2>8. Third-Party Links</h2>
      <p>Our website or messages may contain links to third-party websites or platforms (e.g., YouTube, Instagram, WhatsApp). We are not responsible for the privacy practices or content of these external sites.</p>
    </section>

    <section>
      <h2>9. Children's Privacy</h2>
      <p>Our services are intended for individuals aged 18 and above. We do not knowingly collect data from minors without parental or guardian consent.</p>
    </section>

    <section>
      <h2>10. Changes to This Policy</h2>
      <p>We may update this Privacy Policy from time to time. Any changes will be reflected on this page with a revised effective date. Continued use of our services after changes indicates acceptance of the updated policy.</p>
    </section>
  </div>

  <!-- Footer -->
  <footer class="footer">
    <div class="container">
      <div class="footer-content">
        <div class="footer-about">
          <h3>Debdarshan Wisdom</h3>
          <p>
            Providing accurate astrological guidance since 1995. Helping
            clients navigate life's challenges through the wisdom of the
            stars.
          </p>
          <div class="social-links">
            <a href="#"><i class="fab fa-facebook-f"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-youtube"></i></a>
          </div>
        </div>

        <div class="footer-links">
          <h3>Quick Links</h3>
          <ul>
            <li><a href="#home">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="#contact">Contact</a></li>
            <li><a href="privacy-policy.php">Privacy Policy</a></li>
          </ul>
        </div>

        <div class="footer-services">
          <h3>Our Services</h3>
          <ul>
            <li><a href="#">Horoscope Reading</a></li>
            <li><a href="#">Career Guidance</a></li>
            <li><a href="#">Marriage Compatibility</a></li>
            <li><a href="#">Gemstone Recommendation</a></li>
            <li><a href="#">Numerology</a></li>
          </ul>
        </div>

        <div class="footer-contact">
          <h3>Contact Us</h3>
          <p>
            <i class="fas fa-map-marker-alt"></i> 115D Rashbehari Avenue, Kolkata- 700029
          </p>
          <p><i class="fas fa-phone"></i> <a href="tel:+918240404258" style="color: inherit; text-decoration: none;">9330027339/9830078634</a></p>
          <p><i class="fas fa-envelope"></i> achariyadebdutta@gmail.com</p>
        </div>
      </div>

      <div class="footer-bottom">
        <p>© 2025 AIM Digitalise. All Rights Reserved.</p>
      </div>
    </div>
  </footer>
</body>
</html>